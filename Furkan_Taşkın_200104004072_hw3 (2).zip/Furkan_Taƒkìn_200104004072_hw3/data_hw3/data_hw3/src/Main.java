import java.util.Scanner;

/**
 * Main class for the Electronics Inventory Management System.
 * This class contains the main method to run the program.
 */
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Inventory inventory = new Inventory();

        System.out.println("Welcome to the Electronics Inventory Management System!");

        int choice;
        do {
            printMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addDevice(scanner, inventory);
                    break;
                case 2:
                    removeDevice(scanner, inventory);
                    break;
                case 3:
                    updateDevice(scanner, inventory);
                    break;
                case 4:
                    inventory.displayInventory();
                    break;
                case 5:
                    findCheapestDevice(scanner, inventory);
                    break;
                case 6:
                    inventory.sortDevices();
                    break;
                case 7:
                    System.out.println("Total inventory value: $" + inventory.calculateTotalValue());
                    break;
                case 8:
                    restockDevice(scanner, inventory);
                    break;
                case 9:
                    inventory.exportInventory();
                    break;
                case 0:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);

        scanner.close();
    }

    /**
     * O(1)
     * Prints the menu options.
     */
    private static void printMenu() {
        System.out.println("Please select an option:");
        System.out.println("1. Add a new device");
        System.out.println("2. Remove a device");
        System.out.println("3. Update device details");
        System.out.println("4. List all devices");
        System.out.println("5. Find the cheapest device");
        System.out.println("6. Sort devices by price");
        System.out.println("7. Calculate total inventory value");
        System.out.println("8. Restock a device");
        System.out.println("9. Export inventory report");
        System.out.println("0. Exit");
    }

    /**
     * Prompts the user to add a new device and adds it to the inventory.
     * @param scanner Scanner object for user input
     * @param inventory Inventory object
     * Time Complexity: O(1) because the number of categories is fixed.
     */
    private static void addDevice(Scanner scanner, Inventory inventory) {
        System.out.println("Enter category name:");
        String category = scanner.nextLine();
        System.out.println("Enter device name:");
        String name = scanner.nextLine();
        System.out.println("Enter price:");
        double price = Double.parseDouble(scanner.nextLine());
        System.out.println("Enter quantity:");
        int quantity = Integer.parseInt(scanner.nextLine());

        Device newDevice;
        switch (category.toLowerCase()) {
            case "smart phone":
                newDevice = new SmartPhone(name, price, quantity);
                break;
            case "computer":
                newDevice = new Computer(name, price, quantity);
                break;
            case "tv":
                newDevice = new Television(name, price, quantity);
                break;
            case "headphone":
                newDevice = new Headphone(name, price, quantity);
                break;
            case "coffee machine":
                newDevice = new CofffeMachine(name, price, quantity);
                break;
            default:
                System.out.println("Invalid category. Device not added.");
                return;
        }

        inventory.addDevice(newDevice);
        System.out.printf("%s, %s, %.2f$, %d amount added...%n", category, name, price, quantity);
        System.out.println("Device added successfully.");
    }

    /**
     * Prompts the user to remove a device from the inventory.
     * @param scanner Scanner object for user input
     * @param inventory Inventory object
     * Time Complexity: O(n) because it goes through all the devices in the inventory.
     */
    private static void removeDevice(Scanner scanner, Inventory inventory) {
        System.out.println("Enter category name:");
        String category = scanner.nextLine().toLowerCase().trim(); // Normalize for comparison
        System.out.println("Enter device name:");
        String name = scanner.nextLine().toLowerCase().trim(); // Normalize for comparison
        Device device = inventory.getDevice(category, name);
        if (device != null) {
            inventory.removeDevice(device.getName());
        } else {
            System.out.println("Device not found.");
        }
    }

    /**
     * Prompts the user to update details of a device in the inventory.
     * @param scanner Scanner object for user input
     * @param inventory Inventory object
     * Time Complexity: O(n) because it goes through all the devices in the inventory.
     */
    private static void updateDevice(Scanner scanner, Inventory inventory) {
        System.out.println("Enter category name:");
        String category = scanner.nextLine();
        System.out.println("Enter device name:");
        String name = scanner.nextLine();
        Device device = inventory.getDevice(category, name);
        if (device != null) {
            System.out.println("Enter new name (leave blank to keep current name):");
            String newName = scanner.nextLine();
            if (!newName.isEmpty()) {
                device.setName(newName);
            }
            System.out.println("Enter new price (leave blank to keep current price):");
            double newPrice = scanner.nextDouble();
            if (newPrice != 0) {
                device.setPrice(newPrice);
            }
            System.out.println("Enter new quantity (leave blank to keep current quantity):");
            int newQuantity = scanner.nextInt();
            if (newQuantity != 0) {
                device.setQuantity(newQuantity);
            }
            System.out.println("Device details updated successfully.");
        } else {
            System.out.println("Device not found.");
        }
    }

    /**
     * Prompts the user to find the cheapest device in a specific category.
     * @param scanner Scanner object for user input
     * @param inventory Inventory object
     *   Time Complexity: O(n) because it goes through all the devices in the inventory.
     */

    // find the cheapest device in the inventory
    private static void findCheapestDevice(Scanner scanner, Inventory inventory) {
        System.out.println("The cheapest device is:");
        System.out.println("Category: " + inventory.getMinPriceDevice().getCategory() + " Name: " + inventory.getMinPriceDevice().getName() + " Price: " + inventory.getMinPriceDevice().getPrice() + " Quantity: " + inventory.getMinPriceDevice().getQuantity());
    }

    /**
     * Prompts the user to restock a device in the inventory.
     * @param scanner Scanner object for user input
     * @param inventory Inventory object
     * Time Complexity: O(n) because it goes through all the devices in the inventory.
     */
    private static void restockDevice(Scanner scanner, Inventory inventory) {
        System.out.println("Enter category name:");
        String category = scanner.nextLine();
        System.out.println("Enter device name:");
        String name = scanner.nextLine();
        Device device = inventory.getDevice(category, name);
        if (device != null) {
            System.out.println("Do you want to add or remove stock? (Add/Remove):");
            String action = scanner.nextLine();
            System.out.println("Enter the quantity:");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            if (action.equalsIgnoreCase("Add")) {
                inventory.restockDevice(device, quantity);
                System.out.println("Device restocked successfully.");
            } else if (action.equalsIgnoreCase("Remove")) {
                inventory.restockDevice(device, -quantity);
                System.out.println("Stock removed successfully.");
            } else {
                System.out.println("Invalid action.");
            }
        } else {
            System.out.println("Device not found.");
        }
    }
}
