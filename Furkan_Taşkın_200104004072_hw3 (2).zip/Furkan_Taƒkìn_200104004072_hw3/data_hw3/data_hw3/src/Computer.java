/**
 * Computer class that implements Device interface

 */
public class Computer implements Device{

        private final String category ="Computer";
        private String name;
        private double price;
        private int quantity;

        /**
         * Constructor for Computer
         * @param name
         * @param price
         * @param quantity
         * Time Complexity: O(1)
         */
        public Computer(String name, double price, int quantity) {
            this.name = name;
            this.price = price;
            this.quantity = quantity;
        }

        /**
         * Getter for category
         * @return category
         * Time Complexity: O(1)
         */
        public String getCategory() {
            return category;
        }

        /**
         * Getter for name
         * @return name
         * Time Complexity: O(1)
         */
        public String getName() {
            return name;
        }

        /**
         * Setter for name
         * @param name
         * Time Complexity: O(1)
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * Getter for price
         * @return price
         * Time Complexity: O(1)
         */
        public double getPrice() {
            return price;
        }

        /**
         * Setter for price
         * @param price
         * Time Complexity: O(1)
         */
        public void setPrice(double price) {
            this.price = price;
        }

        /**
         * Getter for quantity
         * @return quantity
         * Time Complexity: O(1)
         */
        public int getQuantity() {
            return quantity;
        }

        /**
         * Setter for quantity
         * @param quantity
         * Time Complexity: O(1)
         */
        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
}
