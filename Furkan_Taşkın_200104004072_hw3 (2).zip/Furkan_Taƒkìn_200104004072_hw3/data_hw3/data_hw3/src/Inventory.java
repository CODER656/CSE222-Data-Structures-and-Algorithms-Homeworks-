import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
/**
 * Inventory class for the Electronics Inventory Management System.
 * This class contains methods to manage the inventory of devices.
 */
public class Inventory {

     //linked list of array lists
    private LinkedList<ArrayList<Device>> inventory = new LinkedList<>();


    /**
     * O(n) because it goes through all the categories in the inventory.
     * Adds a device to the inventory using the category
     * @param device
     */
    public void addDevice(Device device){
        //check if the device is already in the inventory
        for(ArrayList<Device> list : inventory){
            if(list.get(0).getCategory().equals(device.getCategory())){
                list.add(device);
                return;
            }
        }
        //if the device is not in the inventory, add it
        ArrayList<Device> list = new ArrayList<>();
        list.add(device);
        inventory.add(list);
    }


    /**
     * O(n^2) because it goes through all the categories in the inventory, then goes through all the devices in each category.
     * Removes a device from the inventory using the name
     * @param nameToDelete
     */
    public void removeDevice(String nameToDelete) {
        for (ArrayList<Device> categoryList : inventory) { // for each category in the inventory
            Iterator<Device> iterator = categoryList.iterator(); // get iterator for the category

            while (iterator.hasNext()) { // while there are devices in the category
                Device device = iterator.next(); // get the next device

                if (device.getName().equalsIgnoreCase(nameToDelete)) {
                    iterator.remove();
                    System.out.println("Device removed successfully!");
                    return;
                }
            }
        }
        System.out.println("Device not found.");
    }


    /**
     * O(n^2) because it goes through all the categories in the inventory, then goes through all the devices in each category.
     * Gets a device from the inventory using the category and name
     * @param category
     * @param name
     * @return Device
     */
    public Device getDevice(String category, String name) {
        category = category.toLowerCase().trim(); // Normalize
        name = name.toLowerCase().trim(); // Normalize

        for (ArrayList<Device> list : inventory) {
            if (list.get(0).getCategory().equalsIgnoreCase(category)) {
                for (Device device : list) {
                    if (device.getName().equalsIgnoreCase(name)) {
                        return device;
                    }
                }
            }
        }
        return null;
    }


    /***
     * O(n^2) because it goes through all the categories in the inventory, then goes through all the devices in each category.
     * @param device
     * @param name
     * @param price
     * @param quantity
     * Updates the device with the new name, price, and quantity
     */
    public void updateDevice(Device device, String name, double price, int quantity){
        for(ArrayList<Device> list : inventory){
            if(list.get(0).getCategory().equals(device.getCategory())){
                for(Device d : list){
                    if(d.getName().equals(device.getName())){
                        d.setName(name);
                        d.setPrice(price);
                        d.setQuantity(quantity);
                        return;
                    }
                }
            }
        }
    }


    /**
     * O(n) because it goes through all the devices in the inventory.
     * Gets the cheapest device from the inventory
     * @return Device
     */
    public Device getMinPriceDevice(){
        Device minPriceDevice = null;
        double minPrice = Double.MAX_VALUE;
        for(ArrayList<Device> list : inventory){
            for(Device device : list){
                if(device.getPrice() < minPrice){
                    minPrice = device.getPrice();
                    minPriceDevice = device;
                }
            }
        }
        return minPriceDevice;
    }

    /**
     * O(n^2) because it goes through all the categories in the inventory, then goes through all the devices in each category.
     * Gets the total quantity of devices in a specific category
     */
    public void sortDevices() {
        ArrayList<Device> allDevices = new ArrayList<>();
        for (ArrayList<Device> list : inventory) {
            allDevices.addAll(list);
        }

        allDevices.sort((d1, d2) -> Double.compare(d1.getPrice(), d2.getPrice()));

        System.out.println("Devices sorted by price:");
        int count = 1;
        for (Device device : allDevices) {
            System.out.printf("%d. Category: %s, Name: %s, Price: $%.2f, Quantity: %d%n", count++, device.getCategory(), device.getName(), device.getPrice(), device.getQuantity());
        }
    }

    /**
     * O(n) because it goes through all the devices in the inventory.
     * Calculates the total value of the inventory
     * @return double
     */
    public double calculateTotalValue(){
        double totalValue = 0;
        for(ArrayList<Device> list : inventory){
            for(Device device : list){
                totalValue += device.getPrice() * device.getQuantity();
            }
        }
        return totalValue;
    }

    /**
     * O(n^2) because it goes through all the categories in the inventory, then goes through all the devices in each category.
     * Restocks a device in the inventory
     * @param device
     * @param quantity
     */
    public void restockDevice(Device device, int quantity){
        for(ArrayList<Device> list : inventory){
            if(list.get(0).getCategory().equals(device.getCategory())){
                for(Device d : list){
                    if(d.getName().equals(device.getName())){
                        d.setQuantity(d.getQuantity() + quantity);
                        return;
                    }
                }
            }
        }
    }


    /**
     * Time Complexity: O(n^2)
     * First goes through all the categories in the inventory, then goes through all the devices in each category.
     *
     */
    public void displayInventory() {
        System.out.println("Device List:");
        int count = 1;
        for (ArrayList<Device> categoryList : inventory) {
            for (Device device : categoryList) {
                System.out.printf("%d. Category: %s, Name: %s, Price: $%.2f, Quantity: %d%n", count++, device.getCategory(), device.getName(), device.getPrice(), device.getQuantity());
            }
        }
    }


    /**
     * O(n) because it goes through all the devices in the inventory and prints them to a file.
     * Exports the inventory to a text file
     * @throws IOException
     *
     */
    public void exportInventory() {
        try {
            FileWriter writer = new FileWriter("inventory_report.txt");
            writer.write("Electronics Shop Inventory Report\n");
            writer.write("Generated on: " + java.time.LocalDate.now() + "\n");
            writer.write("---------------------------------------\n");
            writer.write("| No. | Category | Name | Price | Quantity |\n");
            writer.write("---------------------------------------\n");

            int count = 1;
            for (ArrayList<Device> list : inventory) {
                for (Device device : list) {
                    writer.write(String.format("| %-4d | %-10s | %-20s | $%-7.2f | %-8d |\n", count++, device.getCategory(), device.getName(), device.getPrice(), device.getQuantity()));
                }
            }

            writer.write("---------------------------------------\n");
            writer.write("Summary:\n");
            writer.write("- Total Number of Devices: " + calculateTotalDevices() + "\n");
            writer.write("- Total Inventory Value: $" + String.format("%.2f", calculateTotalValue()) + "\n");
            writer.write("End of Report");
            writer.close();
            System.out.println("Inventory report exported successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while exporting the inventory report.");
            e.printStackTrace();
        }
    }


    /**
     * O(n) because it goes through all the devices in the inventory.
     * Calculates the total number of devices in the inventory
     * @return int
     */
    private int calculateTotalDevices() {
        int totalDevices = 0;
        for (ArrayList<Device> list : inventory) {
            totalDevices += list.size();
        }
        return totalDevices;
    }

}
