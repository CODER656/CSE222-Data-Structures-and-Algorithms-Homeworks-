/**
 * Interface for a device.
 */
public interface Device {
    /**
     * Getter for category
     * @return category
     * Time Complexity: O(1)
     */
    String getCategory();

    /**
     * Getter for name
     * @return name
     * Time Complexity: O(1)
     */
    String getName();

    /**
     * Setter for name
     * @param name
     * Time Complexity: O(1)
     */
    void setName(String name);
    /**
     * Getter for price
     * @return price
     * Time Complexity: O(1)
     */
    double getPrice();
    /**
     * Setter for price
     * @param price
     * Time Complexity: O(1)
     */
    void setPrice(double price);
    /**
     * Getter for quantity
     * @return quantity
     * Time Complexity: O(1)
     */
    int getQuantity();
    /**
     * Setter for quantity
     * @param quantity
     * Time Complexity: O(1)
     */
    void setQuantity(int quantity);
}
