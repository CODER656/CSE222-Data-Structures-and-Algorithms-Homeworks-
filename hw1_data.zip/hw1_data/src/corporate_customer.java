public class corporate_customer extends customer{

    private String company_name;
    public corporate_customer(String name, String surname, String address, String phone, int ID, int operatorID, String company_name) {
        super(name, surname, address, phone, ID, operatorID);
        this.company_name = company_name;
    }

    @Override
    public void print_customer() {
        System.out.println("Name & Surname: " + getName() + " " + getSurname() + "\nAddress: " + getAddress() + "\nPhone: " + getPhone() + "\nID: " + getID() + "\nOperator ID: " +getOperator_ID() + "\nCompany Name: " + company_name);
    }

    public String getCompany_name() {
        return company_name;
    }

    public void setCompany_name(String company_name) {
        this.company_name = company_name;
    }


    public void define_orders(order[] orders) {
        for (int i = 0; i < orders.length; i++) {
            if (orders[i] != null) {
                if (orders[i].getCustomer_ID() == getID()) {
                    this.getOrders()[getOrderCount()] = orders[i];
                    setOrderCount(getOrderCount() + 1);
                }
            }
        }
    }







}
