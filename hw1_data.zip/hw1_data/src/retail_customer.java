public class retail_customer extends customer{

    public retail_customer(String name, String surname, String address, String phone, int ID, int operatorID) {
        super(name, surname, address, phone, ID, operatorID); // Call super constructor
    }

    public void define_orders(order[] orders) {
        for (int i = 0; i < orders.length; i++) { // Iterate over all orders
            if (orders[i] != null) { // Add null check
                if (orders[i].getCustomer_ID() == getID()) { // Check if order belongs to this customer
                    this.getOrders()[getOrderCount()] = orders[i]; // Add order to customer's order list
                    setOrderCount(getOrderCount() + 1); // Increment order count
                }
            }
        }
    }





}
