public class customer extends person{

    private order[] orders;
    private int operator_ID;
    private int orderCount;

    public customer(String name, String surname, String address, String phone, int ID, int operatorID){
        super(name, surname, address, phone, ID);
        this.operator_ID = operatorID;
        this.orders = new order[100]; // Initialize array to store orders
        this.orderCount = 0;
    }

    public int getOperator_ID() {
        return operator_ID;
    }

    public void setOperator_ID(int operator_ID) {
        this.operator_ID = operator_ID;
    }

    public void setOrders(order[] orders) {
        this.orders = orders;
    }

    public order[] getOrders() {
        return orders;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }


    public void print_customer() {
        System.out.println("Name and Surname: " + getName() + " " + getSurname() + "\nAddress: " + getAddress() + "\nPhone: " + getPhone() + "\nID: " + getID() + "\nOperator ID: " + operator_ID);
    }

    public void print_orders() {
        if (orders != null) { // Add null check
            order.resetOrderNumber(); // Reset order number for printing
            for (int i = 0; i < orderCount; i++) { // Iterate only up to orderCount
                if (orders[i] != null) { // Ensure order exists before printing
                    orders[i].print_order(); // Print order
                }
            }
        } else {
            System.out.println("This customer doesn't have any orders.");
        }
    }

    public void define_orders(order[] allOrders) {
        int orderIndex = 0;
        for (int i = 0; i < orderCount; i++) { // Iterate up to orderCount
            if (allOrders[i] != null && allOrders[i].getCustomer_ID() == this.getID()) { // Add null check
                this.orders[orderIndex++] = allOrders[i];
            }
        }
    }





}
