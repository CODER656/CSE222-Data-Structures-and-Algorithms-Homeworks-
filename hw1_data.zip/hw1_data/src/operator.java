public class operator extends person{

    private int wage;
    private customer[] customers;

    private int customerCount;

    public operator(String name, String surname, String address, String phone, int ID, int wage) {
        super(name, surname, address, phone, ID);
        this.wage = wage;
        this.customers = new customer[100]; // Initialize array to store customers
        this.customerCount = 0;
    }

    public int getWage() {
        return wage;
    }

    public int getCustomerCount() {
        return customerCount;
    }

    public customer[] getCustomers() {
        return customers;
    }

    public void setWage(int wage) {
        this.wage = wage;
    }

    void print_operator() {
        System.out.println("Name and Surname: " + getName() + " " + getSurname() + "\nAddress: " + getAddress() + "\nPhone: " + getPhone() + "\nID: " + getID() + "\nWage: " + wage);
    }

    void print_customers() {
        for (int i = 0; i < customerCount; i++) { // Iterate only up to customerCount
            if (customers[i] != null) { // Ensure customer exists before printing
                customers[i].print_customer();
            }
        }
    }


    void define_customers(customer[] customers) {
        for (int i = 0; i < customers.length; i++) { // Iterate over all customers
            if (customers[i] != null && customers[i].getOperator_ID() == getID()) {  //  null check and operator ID check
                this.customers[customerCount] = customers[i]; // Add customer to operator's customer list
                customerCount++;
            }
        }
    }

}
