import java.io.File;
import java.util.Scanner;

public class Main {
    static operator[] operators = new operator[100];
    static customer[] customers = new customer[100];
    static order[] orders = new order[100];
    static int operatorCount = 0;
    static int customerCount = 0;
    static int orderCount = 0;

    static int[] usedIDs = new int[100]; // Initialize array to store used IDs
    static int usedIDCount = 0; // Counter for the number of used IDs

    public static void main(String[] args) {

        readDataFromFile();

        // *** 2. Association: Customers to operators, orders to customers ***
        for (int i = 0; i < operatorCount; i++) {
            operators[i].define_customers(customers); // Define customers for each operator
        }
        for (int i = 0; i < customerCount; i++) {
            customers[i].define_orders(orders); // Define orders for each customer
        }

        // *** 3. User input (ID) ***
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter your ID... \n");

        if (!input.hasNextInt()) {
            System.out.println("Invalid ID. Please enter a valid number.");
            input.close();
            return;
        }

        int inputID = input.nextInt(); // Read the input ID

        // Check if the ID is valid
        if (inputID <= 0 || inputID >= Integer.MAX_VALUE) {
            System.out.println("Invalid ID. Please enter a valid number.");
            input.close();
            return;
        }

        // *** 4. Search and Print Results ***
        int found = 0;

        // Search for operator
        for (int i = 0; i < operatorCount; i++) {
            if (operators[i].getID() == inputID) { // If operator found
                printOperatorDetails(operators[i]); // Print operator details
                found = 1;
                break;
            }
        }

        // Search for customer (if operator not found)
        if (found == 0) {
            for (int i = 0; i < customerCount; i++) { // If customer found
                if (customers[i].getID() == inputID) { // Print customer details
                    printCustomerDetails(customers[i]); // Print customer details
                    found = 1;
                    break;
                }
            }
        }

        // Error message if ID not found
        if (found == 0) {
            System.out.println("No operator/customer was found with ID " + inputID + ". Please try again.");
        }

        input.close();
    }

    // Helper methods for printing
    private static void printOperatorDetails(operator op) {
        System.out.println("*** Operator Screen ***");
        System.out.println("---------------------------");
        op.print_operator(); // Print operator details
        System.out.println("---------------------------");

        if (op.getCustomerCount() > 0) {
            int customerNum = 1; // Counter for customer numbering
            for (int i = 0; i < op.getCustomerCount(); i++) {
                customer cust = op.getCustomers()[i]; // Get the customer

                System.out.println("Customer #" + customerNum + " (a " +
                        (cust instanceof retail_customer ? "retail" : "corporate") + " customer):"); // checks if the customer is retail or corporate

                cust.print_customer(); // Print customer details
                cust.print_orders();  // Print customer orders

                System.out.println("---------------------------");
                customerNum++; // Increment customer number
            }
        } else {
            System.out.println("This operator doesn't have any customer.");
            System.out.println("---------------------------");
        }
    }

    private static void printCustomerDetails(customer cust) {
        System.out.println("*** Customer Screen ***");
        cust.print_customer(); // Print customer details
        cust.print_orders();    // Print customer orders
        System.out.println("---------------------------");
    }


     static void readDataFromFile() {
        try {
            File file = new File("content.txt"); // Read from content.txt
            Scanner scanner = new Scanner(file); // Create a scanner to read from file

            while (scanner.hasNextLine()) { // Read line by line
                String line = scanner.nextLine(); // Read the line
                String[] parts = line.split(";",-1); // Split the line by semicolon

                if (parts.length < 2) continue;  // Skip the line if it doesn't have at least 2 parts

                try {
                    switch (parts[0]) {
                        case "order":
                            if (parts.length == 6) {
                                String productName = parts[1];
                                int count = Integer.parseInt(parts[2]);
                                if (count <= 0 || count >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                int totalPrice = Integer.parseInt(parts[3]);
                                if (totalPrice <= 0 || totalPrice >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                int status = Integer.parseInt(parts[4]);
                                if (status < 0 || status > 3) {
                                    continue;
                                }
                                int customerID = Integer.parseInt(parts[5]);
                                if (customerID <= 0 || customerID >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                orders[orderCount++] = new order(productName, count, totalPrice, status, customerID);
                            }
                            break;
                        case "retail_customer":
                            if (parts.length == 7) {
                                if (parts[1].isEmpty() || parts[2].isEmpty() || parts[3].isEmpty() ||
                                        parts[4].isEmpty() || parts[6].isEmpty()) {
                                    continue; // Ignore the line if any string is empty
                                }
                                String name = parts[1];
                                String surname = parts[2];
                                String address = parts[3];
                                String phone = parts[4];
                                int ID = Integer.parseInt(parts[5]);
                                if (ID <= 0 || ID >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                if (isIDAvailable(ID, usedIDs, usedIDCount) == 0) {
                                    continue;
                                }
                                usedIDs[usedIDCount++] = ID; // Add the ID to the usedIDs array
                                int operatorID = Integer.parseInt(parts[6]);
                                if (operatorID <= 0 || operatorID >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                retail_customer retailCustomer = new retail_customer(name, surname, address, phone, ID, operatorID);
                                customers[customerCount++] = retailCustomer;
                            }
                            break;
                        case "corporate_customer":
                            if (parts.length == 8) {
                                if (parts[1].isEmpty() || parts[2].isEmpty() || parts[3].isEmpty() ||
                                        parts[4].isEmpty() || parts[7].isEmpty()) {
                                    continue; // Ignore the line if any string is empty
                                }
                                String name = parts[1];
                                String surname = parts[2];
                                String address = parts[3];
                                String phone = parts[4];
                                int ID = Integer.parseInt(parts[5]);
                                if (ID <= 0 || ID >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                if (isIDAvailable(ID, usedIDs, usedIDCount) == 0) {
                                    continue;
                                }
                                usedIDs[usedIDCount++] = ID; // Add the ID to the usedIDs array
                                int operatorID = Integer.parseInt(parts[6]);
                                if (operatorID <= 0 || operatorID >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                String companyName = parts[7];
                                corporate_customer corporateCustomer = new corporate_customer(name, surname, address, phone, ID, operatorID, companyName);
                                customers[customerCount++] = corporateCustomer;
                            }
                            break;
                        case "operator":
                            if (parts.length == 7) {
                                if (parts[1].isEmpty() || parts[2].isEmpty() || parts[3].isEmpty() ||
                                        parts[4].isEmpty()) {
                                    continue; // Ignore the line if any string is empty
                                }
                                String name = parts[1];
                                String surname = parts[2];
                                String address = parts[3];
                                String phone = parts[4];
                                int ID = Integer.parseInt(parts[5]);
                                if (ID <= 0 || ID >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                if (isIDAvailable(ID, usedIDs, usedIDCount) == 0) {
                                    continue;
                                }
                                usedIDs[usedIDCount++] = ID; // Add the ID to the usedIDs array

                                int wage = Integer.parseInt(parts[6]);
                                if (wage <= 0 || wage >= Integer.MAX_VALUE) {
                                    continue;
                                }
                                operators[operatorCount++] = new operator(name, surname, address, phone, ID, wage);
                            }
                            break;
                    }
                }
                catch (NumberFormatException e) {
                }
            }
            scanner.close();
        } catch (Exception e) {
            System.out.println("An error occurred while reading data from file.");
            e.printStackTrace();
        }
    }

    public static int isIDAvailable(int id, int[] usedIDs, int usedIDCount) { // Check if ID is available
        for (int i = 0; i < usedIDCount; i++) {
            if (usedIDs[i] == id) { // If ID is already used
                return 0;
            }
        }
        return 1;
    }


}
